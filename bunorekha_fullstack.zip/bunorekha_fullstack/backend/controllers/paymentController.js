const Payment = require('../models/Payment');

// @desc    Create a new payment
// @route   POST /api/payments
// @access  Private
const createPayment = async (req, res) => {
  const { order, amount, paymentMethod, paymentStatus } = req.body;

  if (!order || !amount || !paymentMethod) {
    return res.status(400).json({ message: 'Missing required payment fields' });
  }

  try {
    const payment = new Payment({
      user: req.user._id,
      order,
      amount,
      paymentMethod,
      paymentStatus: paymentStatus || 'pending',
    });

    const createdPayment = await payment.save();
    res.status(201).json(createdPayment);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Get payments for logged in user
// @route   GET /api/payments/my
// @access  Private
const getPaymentsByUser = async (req, res) => {
  try {
    const payments = await Payment.find({ user: req.user._id }).populate('order');
    res.json(payments);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Get all payments (admin)
// @route   GET /api/payments
// @access  Private/Admin
const getAllPayments = async (req, res) => {
  try {
    const payments = await Payment.find().populate('user', 'name email').populate('order');
    res.json(payments);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
};

module.exports = {
  createPayment,
  getPaymentsByUser,
  getAllPayments,
};
