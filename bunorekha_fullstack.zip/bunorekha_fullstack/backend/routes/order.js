const express = require('express');
const { protect, admin } = require('../middleware/authMiddleware');
const { createOrder, getOrderById, getUserOrders, getAllOrders, updateOrderStatus, deleteOrder } = require('../controllers/orderController');

const router = express.Router();

router.use(protect);

router.post('/', createOrder);
router.get('/myorders', getUserOrders);
router.get('/:id', getOrderById);

router.use(admin);

router.get('/', getAllOrders);
router.put('/:id/status', updateOrderStatus);
router.delete('/:id', deleteOrder);

module.exports = router;
