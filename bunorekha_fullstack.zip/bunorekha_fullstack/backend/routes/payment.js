const express = require('express');
const { protect } = require('../middleware/authMiddleware');
const { createPayment, getPaymentsByUser, getAllPayments } = require('../controllers/paymentController');
const { admin } = require('../middleware/authMiddleware');

const router = express.Router();

router.use(protect);

router.post('/', createPayment);
router.get('/my', getPaymentsByUser);

router.use(admin);

router.get('/', getAllPayments);

module.exports = router;
