const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  slug: { type: String, required: true, unique: true, lowercase: true, trim: true },
  description: { type: String, required: true },
  longDescription: { type: String },
  category: { type: String, required: true },
  style: { type: String },
  tags: [{ type: String }],
  price: { type: Number, required: true },
  originalPrice: { type: Number },
  images: [{ type: String }],
  availableSizes: [{ type: String }],
  availableColors: [{ name: String, hex: String }],
  stock: { type: Number, default: 0 },
  rating: { type: Number, default: 0 },
  reviewsCount: { type: Number, default: 0 },
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model('Product', productSchema);
