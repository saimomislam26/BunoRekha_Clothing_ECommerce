(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_admin_customers_page_tsx_f772b26a._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_admin_customers_page_tsx_f772b26a._.js",
  "chunks": [
    "static/chunks/_ae264897._.js"
  ],
  "source": "dynamic"
});
