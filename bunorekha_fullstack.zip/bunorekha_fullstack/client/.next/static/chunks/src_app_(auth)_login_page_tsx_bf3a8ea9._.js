(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(auth)_login_page_tsx_bf3a8ea9._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(auth)_login_page_tsx_bf3a8ea9._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_d33528e6._.js",
    "static/chunks/node_modules_06cd96cf._.js",
    "static/chunks/src_780a1426._.js"
  ],
  "source": "dynamic"
});
