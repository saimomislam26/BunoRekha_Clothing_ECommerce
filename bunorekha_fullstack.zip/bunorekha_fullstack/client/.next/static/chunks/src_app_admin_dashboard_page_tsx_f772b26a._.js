(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_admin_dashboard_page_tsx_f772b26a._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_admin_dashboard_page_tsx_f772b26a._.js",
  "chunks": [
    "static/chunks/node_modules_lodash_f240f67a._.js",
    "static/chunks/node_modules_recharts_es6_8235043b._.js",
    "static/chunks/node_modules_d027084c._.js",
    "static/chunks/src_b86755ee._.js"
  ],
  "source": "dynamic"
});
