(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(main)_layout_tsx_bf3a8ea9._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(main)_layout_tsx_bf3a8ea9._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_a491aded._.js",
    "static/chunks/node_modules_fc3c30f4._.js",
    "static/chunks/src_components_fd08aaab._.js"
  ],
  "source": "dynamic"
});
