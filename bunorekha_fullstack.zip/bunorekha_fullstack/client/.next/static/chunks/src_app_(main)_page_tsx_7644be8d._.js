(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(main)_page_tsx_7644be8d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(main)_page_tsx_7644be8d._.js",
  "chunks": [
    "static/chunks/node_modules_285df0f9._.js",
    "static/chunks/src_b52d82b2._.js"
  ],
  "source": "dynamic"
});
