(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_admin_products_page_tsx_f772b26a._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_admin_products_page_tsx_f772b26a._.js",
  "chunks": [
    "static/chunks/src_b786f3e6._.js",
    "static/chunks/node_modules_a7eeef8e._.js"
  ],
  "source": "dynamic"
});
