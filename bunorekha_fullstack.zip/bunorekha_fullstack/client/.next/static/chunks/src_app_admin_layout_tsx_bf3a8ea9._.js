(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_admin_layout_tsx_bf3a8ea9._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_admin_layout_tsx_bf3a8ea9._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_34c5696a._.js",
    "static/chunks/node_modules_23dd2509._.js",
    "static/chunks/src_9a5e76da._.js"
  ],
  "source": "dynamic"
});
